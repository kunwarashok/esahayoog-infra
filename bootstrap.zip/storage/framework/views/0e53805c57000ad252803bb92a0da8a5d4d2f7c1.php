<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Entities')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <a href="<?php echo e(route('entity.create')); ?>" class="btn btn-success">Add Entity</a>
                    <br>
                    <br> <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('success')); ?>

                    </div>
                    <?php endif; ?> <?php if(Session::has('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(Session::get('error')); ?>

                    </div>
                    <?php endif; ?>

                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">SN</th>
                                <th scope="col">Entity Name</th>
                                <th scope="col">Type</th>
                                <th scope="col">Logo</th>
                                <th scope="col">Email</th>
                                <th scope="col">Phone</th>
                                <th scope="col">Account Detail</th>
                                <th width ="130" scope="col"> Document</th>
                                 <th scope="col">Verified</th>
                                 <th scope="col">Status</th>
                                <th width="130" scope="col">Action</th>
                               
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $entities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $entity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($key+1); ?></th>
                                <td><?php echo e($entity->name); ?></td>
                                <td><?php echo e($entity->entityType); ?></td>
                                <td>
                                    <?php if($entity->logo): ?>
                                    <img src="<?php echo e(asset('images/'.$entity->logo)); ?>" width="100" alt="<?php echo e($entity->name.' logo'); ?>">
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($entity->email); ?></td>
                                <td><?php echo e($entity->phone); ?></td>
                                <td>
                                    <a href= "<?php echo e(route('account.view', $entity->id)); ?>" button type="button" class="btn btn-primary btn-sm"><i class="far fa-eye"></i></a>                                    
                                    <a href= "<?php echo e(route('account.create', $entity->id)); ?>" button type="button" class="btn btn-success btn-sm"><i class="fas fa-plus"></i></>
                                </td>
                                <td>
                                    
                                    <button type="button" class="btn btn-primary btn-sm"><i class="far fa-eye"></i></button>
                                    <button type="button" class="btn btn-info btn-sm"><i class="fas fa-edit"></i></button>
                                    <button type="button" class="btn btn-success btn-sm"><i class="fas fa-plus"></i></button>
                                </td>
                                <td>
                                    <?php if($entity->verified==1): ?>
                                        <span class="badge bg-success">YES</span>
                                    <?php else: ?>
                                        <span class="badge bg-light text-dark">NO</span>
                                     <?php endif; ?>
                                </td>
                                
                                <td>
                                    <?php if($entity->status==1): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge bg-light text-dark">Inactive</span>
                                     <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('entity.edit', $entity->id)); ?>" class="btn btn-success btn-sm"><i class="fas fa-edit"></i></a>
                                   
                                   <form class="d-inline" action="<?php echo e(route('entity.destroy', $entity->id)); ?>" method="POST" >
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button  type="button" class="btn btn-danger btn-sm btn-delete"><i class="far fa-trash-alt"></i></button>
                                   </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH E:\_projects\_personal\ashok\esahayoog-infra\resources\views/entities/index.blade.php ENDPATH**/ ?>